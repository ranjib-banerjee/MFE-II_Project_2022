library (e1071)
library(readr)
library (caret)

Training = read_csv("C:/Users/Abhinav/Downloads/archive/Training.csv", col_types = cols(...134 = col_skip()))
View(Training)

model = naiveBayes(prognosis ~ ., data = Training)


TestingNEW <- read_csv("C:/Users/Abhinav/Downloads/archive/TestingNEW.csv", col_types = cols(prognosis = col_skip() ) )

predictions = predict ( model, Testing[, -ncol(Testing)] )
predictions

predictionsNEW = predict ( model, TestingNEW )
predictionsNEW

probs <- predict(model, Testing[,-ncol(Testing)], type="raw")
View (probs)
