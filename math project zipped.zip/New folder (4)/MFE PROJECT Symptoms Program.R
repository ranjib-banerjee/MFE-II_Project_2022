oneDisease = subset ( Training, Training$prognosis == "Malaria", select = -c(prognosis) )
observations = nrow (oneDisease)
selected_Symptoms = colSums (oneDisease) > 0.2*observations
oneDisease_Symptoms = oneDisease [, selected_Symptoms]
View (oneDisease_Symptoms)

colSums (oneDisease_Symptoms)/ observations
summary (oneDisease_Symptoms)
