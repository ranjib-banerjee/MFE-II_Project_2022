time <-5
# Reading CSV Files
aapl <- read.csv("Data/APPL5.csv", header = TRUE, sep = ",")
micr<- read.csv("Data/MICR5.csv",header = TRUE,sep=",")
baj = read.csv("Data/BAJAJ.csv")
eic = read.csv("Data/EICHER.csv")
# Ploting Apple Line  Graph
plot(aapl[,1],aapl[,2],type="l",xaxt="n",xlab = "Years",ylab="Price")
title(main="Apple")
axis(1,at = 1:481,labels = aapl[,3][1:481])
Sys.sleep(time)
# Ploting Apple's Non Linear Model
x = aapl[,1]
md2 <- function(x){-3.44 + 0.2598*x + -4.24E-03*x^2 + 2.65E-05*x^3 + -7.09E-08*x^4 + 6.97E-11*x^5}
curve(md2,from = 0,to=481,xaxt="n",main="Apple Non Linear Regression" ,xlab= "Years",ylab = "Price")
axis(1,at = 1:481,labels = aapl[,3][1:481])
a= seq(494,505)
s = sapply(a,md2)
# Predicting Apple's Stock Price
predic1 = data.frame(Months = c("Jan23","Feb23","Mar23","Apr23","May23","June23","July23","Agst23","Sept23","Oct23","Nov23","Dec23"),Price = c(s))
print("Predicted Value  for Apple Stock Price in 2023")
print(predic1)
Sys.sleep(time)
# Ploting Microsoft Line  Graph
plot(micr[,1],micr[,2],type="l",xaxt="n",xlab = "Years",ylab="Price")
axis(1,at = 1:418,labels = micr[,3][1:418])
title(main="Microsoft")
Sys.sleep(time)
# Ploting Microsoft's Non Linear Model
md1 <- function(x){13.4 + -0.972*x + 0.015*x^2 + -6.69E-05*x^3 + 9.38E-08*x^4}
curve(md1,from = 0,to=418,xaxt="n",main="Microsoft Non Linear Regression",xlab= "Years",ylab = "Price")
axis(1,at = 1:418,labels = aapl[,3][1:418])
b= seq(494,505)
s1 = sapply(b,md2)
# Predicting Microsoft's Stock Price
predic2 = data.frame(Months = c("Jan23","Feb23","Mar23","Apr23","May23","June23","July23","Agst23","Sept23","Oct23","Nov23","Dec23"),Price = c(s1))
print("Predicted Value  for Microsoft Stock Price in 2023")
print(predic2)
Sys.sleep(time)
# Ploting Bajaj Line  Graph
plot(seq(1,nrow(baj)),baj[,5],type="l",xaxt="n",xlab = "Years",ylab="Price")
title(main="Bajaj")
axis(1,at = 1:nrow(baj),labels = baj[,1][1:nrow(baj)])
Sys.sleep(time)
# Ploting Bajaj Non Linear Model Graph
mds <- function(x){3584 + 11.4*x + -0.126*x^2 + 3.29E-04*x^3 + 1.71E-07*x^4}
curve(mds,from = 0,to=nrow(baj),xaxt="n",main="Bajaj Non Linear Regression" ,xlab= "Years",ylab = "Price")
axis(1,at = 1:nrow(baj),labels = baj$Date)
Sys.sleep(time)
may = c('01-06-2023', '02-06-2023', '03-06-2023', '04-06-2023', '05-06-2023', '06-06-2023', '07-06-2023', '08-06-2023', '09-06-2023', '10-06-2023', '11-06-2023', '12-06-2023', '13-06-2023', '14-06-2023', '15-06-2023', '16-06-2023', '17-06-2023', '18-06-2023', '19-06-2023', '20-06-2023', '21-06-2023', '22-06-2023', '23-06-2023', '24-06-2023', '25-06-2023', '26-06-2023', '27-06-2023', '28-06-2023', '29-06-2023', '30-06-2023', '31-06-2023')
s3 = sapply(seq(285:315),mds)
# Predicting Price for Bajaj
print("Predicted Vaule of Bajaj Stock Price in May23")
pre3 = data.frame(Date = may,Price  = c(s3))
print(pre3)
Sys.sleep(time)
# Ploting Bajaj Line Graph
plot(seq(1,nrow(eic)),eic[,5],type="l",xaxt="n",xlab = "Years",ylab="Price")
title(main="Eicher")
axis(1,at = 1:nrow(baj),labels = baj[,1][1:nrow(baj)])
Sys.sleep(time)
# Ploting Eicher Non Linear Model Graph
md3 <- function(x){2590 + -5.81*x + 0.316*x^2 + -6.22E-04*x^3 + -2.11E-05*x^4 + 1.3E-07*x^5 + -2.15E-10*x^6}
curve(md3,from = 0,to=nrow(baj),xaxt="n",main="Eicher Non Linear Regression" ,xlab= "Years",ylab = "Price")
axis(1,at = 1:nrow(baj),labels = baj$Date)
Sys.sleep(time)
# Predicting Price for Eicher
s4 = sapply(seq(285:315),md3)
print("Predicted Vaule of Eicher Stock Price in May23")
pre4 = data.frame(Date = may,Price = c(s4))
print(pre4)
